from .Model import Model


class Pivot(Model):
    __primary_key__ = "id"
