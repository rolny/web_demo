class Index:
    def __init__(self, column, name, index_type):
        self.column = column
        self.name = name
        self.index_type = index_type
