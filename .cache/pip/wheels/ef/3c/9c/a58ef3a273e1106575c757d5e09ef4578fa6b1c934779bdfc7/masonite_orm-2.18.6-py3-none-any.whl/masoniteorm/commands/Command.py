from .CanOverrideConfig import CanOverrideConfig
from .CanOverrideOptionsDefault import CanOverrideOptionsDefault


class Command(CanOverrideOptionsDefault, CanOverrideConfig):
    pass
